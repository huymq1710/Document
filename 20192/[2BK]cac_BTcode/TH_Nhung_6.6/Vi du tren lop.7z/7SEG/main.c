#include<reg51.h>

void delay(int);
void Display(char);

int main(void)
{
   char ch = '0';	          

   	P0 = 0x00;   
	P1 = 0x00;   
	P2 = 0x00;   
	P3 = 0x00;  	

	while(1)           
	{
		Display(ch);	  
		delay(30000);			  
		
		ch++;
		if (ch==0x3A)
			ch = '0';
	}
}


void delay(int a)
{
   int i;
   for(i=0;i<a;i++);   
}

void Display(char ch)   
{
	switch(ch)
	{
		case '0':	P0 = ~0x3F;  break;
		case '1':	P0 = ~0x06;  break;
		case '2':	P0 = ~0x5B;  break;
		case '3':	P0 = ~0x4F;  break;
		case '4':	P0 = ~0x66;  break;
		case '5':	P0 = ~0x6D;  break;
		case '6':	P0 = ~0x7D;  break;
		case '7':	P0 = ~0x07;  break;
		case '8':	P0 = ~0x7F;  break;
		case '9':	P0 = ~0x6F;  break;
	

		default: P2 = 0x3F;  break;
	}	
}